import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.janhith.app',
  appName: 'JANHITH',
  webDir: 'dist'
};

export default config;
