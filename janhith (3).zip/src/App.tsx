import React, { useState, useEffect, useRef } from 'react';
import { 
  Camera, MapPin, Send, History, LayoutDashboard, Map as MapIcon, 
  CheckCircle, Clock, AlertCircle, User, LogOut, Menu, X, 
  Plus, Filter, Search, BarChart3, Users, Settings, ArrowRight,
  Loader2, Trash2, Edit2, Construction, Upload, MessageSquare,
  FileText, ShieldCheck, PhoneCall, Zap, Building2, Lock, Shield,
  AlertTriangle, Check, Info, Bell, Moon, Sun, Languages,
  Image as ImageIcon, MessageCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut, User as FirebaseUser,
  signInWithEmailAndPassword, createUserWithEmailAndPassword
} from 'firebase/auth';
import { 
  collection, doc, setDoc, getDoc, onSnapshot, query, where, orderBy, 
  addDoc, serverTimestamp, updateDoc, deleteDoc, Timestamp, arrayUnion
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { UserProfile, Complaint, ComplaintType, ComplaintStatus, Priority, UserRole, ComplaintComment } from './types';
import { analyzeCivicIssue, getChatResponse } from './services/geminiService';
import { cn } from './lib/utils';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, Legend
} from 'recharts';

// --- Translations ---

const translations = {
  en: {
    appName: 'JANHITH',
    tagline: 'Empowering citizens to report civic issues and track resolutions in real-time.',
    reportIssue: 'Report Issue',
    myIssues: 'My Issues',
    dashboard: 'Dashboard',
    map: 'Live Map',
    analytics: 'Analytics',
    chat: 'AI Assistant',
    logout: 'Logout',
    pending: 'Pending',
    inProgress: 'In Progress',
    resolved: 'Resolved',
    rejected: 'Rejected',
    critical: 'Critical',
    high: 'High',
    medium: 'Medium',
    low: 'Low',
    sendTeam: 'Send Team Immediately',
    solveImmediately: 'Solve Immediately',
    adminDashboard: 'Administrative Overview',
    citizenHome: 'Citizen Dashboard',
    notifications: 'Notifications',
  },
  te: {
    appName: 'జనహిత',
    tagline: 'పౌరులు పౌర సమస్యలను నివేదించడానికి మరియు నిజ సమయంలో పరిష్కారాలను ట్రాక్ చేయడానికి అధికారం ఇవ్వడం.',
    reportIssue: 'సమస్యను నివేదించండి',
    myIssues: 'నా సమస్యలు',
    dashboard: 'డాష్‌బోర్డ్',
    map: 'లైవ్ మ్యాప్',
    analytics: 'విశ్లేషణలు',
    chat: 'AI అసిస్టెంట్',
    logout: 'లాగ్ అవుట్',
    pending: 'పెండింగ్‌లో ఉంది',
    inProgress: 'పురోగతిలో ఉంది',
    resolved: 'పరిష్కరించబడింది',
    rejected: 'తిరస్కరించబడింది',
    critical: 'క్లిష్టమైనది',
    high: 'ఎక్కువ',
    medium: 'మధ్యస్థం',
    low: 'తక్కువ',
    sendTeam: 'వెంటనే బృందాన్ని పంపండి',
    solveImmediately: 'వెంటనే పరిష్కరించండి',
    adminDashboard: 'పరిపాలనా అవలోకనం',
    citizenHome: 'పౌర డాష్‌బోర్డ్',
    notifications: 'నోటిఫికేషన్‌లు',
  }
};

// --- Components ---

const Button = ({ children, className, variant = 'primary', ...props }: any) => {
  const variants = {
    primary: 'bg-slate-900 text-white hover:bg-slate-800 shadow-sm',
    secondary: 'bg-white text-slate-900 border border-slate-900 hover:bg-slate-50 shadow-sm',
    outline: 'bg-transparent text-slate-600 border border-slate-200 hover:bg-slate-50',
    ghost: 'bg-transparent text-slate-600 hover:bg-slate-50',
    danger: 'bg-rose-600 text-white hover:bg-rose-700 shadow-sm',
  };
  return (
    <button 
      className={cn(
        'px-5 py-2.5 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]',
        variants[variant as keyof typeof variants],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};

const Card = ({ children, className, onClick }: any) => (
  <div 
    onClick={onClick}
    className={cn(
      'bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden transition-all',
      onClick && 'cursor-pointer hover:shadow-md hover:border-slate-200',
      className
    )}
  >
    {children}
  </div>
);

const Badge = ({ children, variant = 'default', className }: any) => {
  const variants = {
    default: 'bg-slate-100 text-slate-700',
    success: 'bg-emerald-50 text-emerald-700 border border-emerald-100',
    warning: 'bg-amber-50 text-amber-700 border border-amber-100',
    danger: 'bg-rose-50 text-rose-700 border border-rose-100',
    info: 'bg-sky-50 text-sky-700 border border-sky-100',
  };
  return (
    <span className={cn('px-3 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold', variants[variant as keyof typeof variants], className)}>
      {children}
    </span>
  );
};

interface Notification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  isRead: boolean;
  uid: string;
}

const NotificationBell = ({ uid, t }: { uid: string, t: any }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const q = query(
      collection(db, 'notifications'),
      where('uid', '==', uid),
      orderBy('createdAt', 'desc')
    );
    return onSnapshot(q, (snapshot) => {
      setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification)));
    });
  }, [uid]);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const markAsRead = async (id: string) => {
    await updateDoc(doc(db, 'notifications', id), { isRead: true });
  };

  return (
    <div className="relative">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 text-gray-400 hover:text-slate-900 transition-colors relative"
      >
        <Bell className="w-6 h-6" />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
            <motion.div 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 overflow-hidden"
            >
              <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                <h3 className="font-bold text-gray-900">{t.notifications}</h3>
                <Badge variant="info">{unreadCount} New</Badge>
              </div>
              <div className="max-h-96 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="p-8 text-center text-gray-400">
                    <Bell className="w-8 h-8 mx-auto mb-2 opacity-20" />
                    <p className="text-sm">No notifications yet</p>
                  </div>
                ) : (
                  notifications.map(n => (
                    <div 
                      key={n.id} 
                      onClick={() => markAsRead(n.id)}
                      className={cn(
                        "p-4 border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors",
                        !n.isRead && "bg-slate-100"
                      )}
                    >
                      <p className="text-sm font-bold text-gray-900 mb-1">{n.title}</p>
                      <p className="text-xs text-gray-600 mb-2">{n.message}</p>
                      <p className="text-[10px] text-gray-400">{new Date(n.createdAt).toLocaleString()}</p>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [language, setLanguage] = useState<'en' | 'te'>('en');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Citizen Login/Register State
  const [isCitizenRegistering, setIsCitizenRegistering] = useState(false);
  const [citizenEmail, setCitizenEmail] = useState('');
  const [citizenPassword, setCitizenPassword] = useState('');
  const [citizenName, setCitizenName] = useState('');
  const [citizenError, setCitizenError] = useState('');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  const t = translations[language];

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        const docRef = doc(db, 'users', firebaseUser.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data() as UserProfile;
          setProfile(data);
          if (data.language) setLanguage(data.language);
          if (data.theme) setTheme(data.theme);
        } else {
          const newProfile: UserProfile = {
            uid: firebaseUser.uid,
            email: firebaseUser.email || '',
            displayName: firebaseUser.displayName || 'User',
            photoURL: firebaseUser.photoURL || '',
            role: 'citizen',
            createdAt: new Date().toISOString(),
            language: 'en',
            theme: 'light',
          };
          await setDoc(docRef, newProfile);
          setProfile(newProfile);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const toggleLanguage = async () => {
    const newLang = language === 'en' ? 'te' : 'en';
    setLanguage(newLang);
    if (user) {
      await updateDoc(doc(db, 'users', user.uid), { language: newLang });
    }
  };

  const toggleTheme = async () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    if (user) {
      await updateDoc(doc(db, 'users', user.uid), { theme: newTheme });
    }
  };

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const handleLogin = async (preferredRole: UserRole = 'citizen') => {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const firebaseUser = result.user;
      
      const docRef = doc(db, 'users', firebaseUser.uid);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        const newProfile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          displayName: firebaseUser.displayName || 'User',
          photoURL: firebaseUser.photoURL || '',
          role: preferredRole,
          createdAt: new Date().toISOString(),
        };
        await setDoc(docRef, newProfile);
        setProfile(newProfile);
      }
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setActiveTab('home');
  };

  const handleCitizenLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCitizenError('');
    try {
      await signInWithEmailAndPassword(auth, citizenEmail, citizenPassword);
    } catch (err: any) {
      setCitizenError(err.message || 'Login failed');
    }
  };

  const handleCitizenRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setCitizenError('');
    if (citizenPassword.length < 6) {
      setCitizenError('Password must be at least 6 characters');
      return;
    }
    try {
      const result = await createUserWithEmailAndPassword(auth, citizenEmail, citizenPassword);
      const user = result.user;
      const newProfile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: citizenName || 'User',
        photoURL: '',
        role: 'citizen',
        createdAt: new Date().toISOString(),
        language: 'en',
        theme: 'light',
      };
      await setDoc(doc(db, 'users', user.uid), newProfile);
      setProfile(newProfile);
    } catch (err: any) {
      setCitizenError(err.message || 'Registration failed');
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 text-slate-900 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <LandingPage 
        onLogin={handleLogin} 
        t={t} 
        language={language} 
        theme={theme} 
        toggleLanguage={toggleLanguage} 
        toggleTheme={toggleTheme}
        isCitizenRegistering={isCitizenRegistering}
        setIsCitizenRegistering={setIsCitizenRegistering}
        citizenEmail={citizenEmail}
        setCitizenEmail={setCitizenEmail}
        citizenPassword={citizenPassword}
        setCitizenPassword={setCitizenPassword}
        citizenName={citizenName}
        setCitizenName={setCitizenName}
        citizenError={citizenError}
        handleCitizenLogin={handleCitizenLogin}
        handleCitizenRegister={handleCitizenRegister}
        deferredPrompt={deferredPrompt}
        handleInstallClick={handleInstallClick}
      />
    );
  }

  if (profile?.role === 'admin' && !profile.isAdminVerified) {
    return <AdminVerification profile={profile} onVerified={() => {
      if (user) {
        getDoc(doc(db, 'users', user.uid)).then(snap => setProfile(snap.data() as UserProfile));
      }
    }} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="bg-slate-900 p-2 rounded-lg">
                <Construction className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900 tracking-tight">JANHITH</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-4">
              <NavLinks profile={profile} activeTab={activeTab} setActiveTab={setActiveTab} />
              <div className="h-6 w-px bg-gray-200 mx-2" />
              <div className="flex items-center gap-3">
                <img src={user.photoURL || ''} className="w-8 h-8 rounded-full border border-gray-200" alt="Profile" />
                <div className="text-sm">
                  <p className="font-medium text-gray-900 leading-none">{user.displayName}</p>
                  <p className="text-xs text-gray-500 capitalize">{profile?.role}</p>
                </div>
                <button onClick={handleLogout} className="p-2 text-gray-400 hover:text-red-600 transition-colors">
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="md:hidden flex items-center">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-gray-600">
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-gray-100 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-1">
                <NavLinks profile={profile} activeTab={activeTab} setActiveTab={(t) => { setActiveTab(t); setIsMenuOpen(false); }} isMobile />
                <div className="pt-4 border-t border-gray-100 flex items-center gap-3">
                  <img src={user.photoURL || ''} className="w-10 h-10 rounded-full" alt="Profile" />
                  <div>
                    <p className="font-medium text-gray-900">{user.displayName}</p>
                    <p className="text-sm text-gray-500 capitalize">{profile?.role}</p>
                  </div>
                </div>
                <Button onClick={handleLogout} variant="ghost" className="w-full justify-start text-red-600 px-0">
                  <LogOut className="w-5 h-5 mr-2" /> Logout
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && profile?.role === 'citizen' && <CitizenHome key="citizen-home" setActiveTab={setActiveTab} />}
          {activeTab === 'home' && profile?.role === 'admin' && profile.isAdminVerified && <AdminDashboard key="admin-dashboard" setActiveTab={setActiveTab} />}
          {activeTab === 'home' && profile?.role === 'worker' && <WorkerTasks key="worker-tasks" />}
          {activeTab === 'report' && <ReportIssue key="report-issue" onComplete={() => setActiveTab('history')} />}
          {activeTab === 'pending' && <ComplaintHistory key="pending" role={profile?.role} uid={user.uid} initialFilter="Pending" />}
          {activeTab === 'resolved' && <ComplaintHistory key="resolved" role={profile?.role} uid={user.uid} initialFilter="Resolved" />}
          {activeTab === 'history' && <ComplaintHistory key="history" role={profile?.role} uid={user.uid} />}
          {activeTab === 'map' && <MapView key="map" />}
          {activeTab === 'analytics' && <AnalyticsView key="analytics" />}
          {activeTab === 'chat' && <ChatInterface key="chat" />}
          {activeTab === 'budget' && <BudgetView key="budget" />}
        </AnimatePresence>
      </main>
      
      {/* Floating Chat Button */}
      {activeTab !== 'chat' && (
        <button 
          onClick={() => setActiveTab('chat')}
          className="fixed bottom-6 right-6 w-14 h-14 bg-slate-900 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-transform z-40"
        >
          <MessageSquare className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}

function AdminLayout({ user, profile, activeTab, setActiveTab, onLogout }: any) {
  return (
    <div className="min-h-screen bg-slate-900 flex overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-slate-950 border-r border-slate-800 flex flex-col hidden lg:flex">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10">
            <div className="bg-slate-900 p-2 rounded-xl shadow-lg shadow-slate-900/20">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white tracking-tighter">JANHITH <span className="text-slate-400">PRO</span></span>
          </div>

          <nav className="space-y-2">
            <AdminNavLink icon={LayoutDashboard} label="Dashboard" active={activeTab === 'home'} onClick={() => setActiveTab('home')} />
            <AdminNavLink icon={Clock} label="Pending" active={activeTab === 'pending'} onClick={() => setActiveTab('pending')} />
            <AdminNavLink icon={CheckCircle} label="Resolved" active={activeTab === 'resolved'} onClick={() => setActiveTab('resolved')} />
            <AdminNavLink icon={MapIcon} label="Live Map" active={activeTab === 'map'} onClick={() => setActiveTab('map')} />
            <AdminNavLink icon={BarChart3} label="Analytics" active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} />
            <AdminNavLink icon={History} label="All Reports" active={activeTab === 'history'} onClick={() => setActiveTab('history')} />
            <AdminNavLink icon={MessageSquare} label="AI Assistant" active={activeTab === 'chat'} onClick={() => setActiveTab('chat')} />
          </nav>
        </div>

        <div className="mt-auto p-6 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3 mb-4">
            <img src={user.photoURL || ''} className="w-10 h-10 rounded-xl border border-slate-700" alt="Admin" />
            <div className="overflow-hidden">
              <p className="text-sm font-bold text-white truncate">{user.displayName}</p>
              <p className="text-[10px] text-slate-500 font-mono truncate">ID: {profile.uid.substring(0, 12)}...</p>
            </div>
          </div>
          <Button 
            onClick={onLogout} 
            variant="ghost" 
            className="w-full justify-start text-slate-400 hover:text-red-400 hover:bg-red-400/10 h-10 px-3"
          >
            <LogOut className="w-4 h-4 mr-2" /> Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden bg-slate-50">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-4">
            <h2 className="text-lg font-bold text-slate-800 capitalize">
              {activeTab === 'home' ? 'Administrative Overview' : activeTab}
            </h2>
            <div className="px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold rounded uppercase tracking-wider">
              System Admin
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg text-slate-600 text-xs font-medium">
              <Clock className="w-3.5 h-3.5" />
              <span>{new Date().toLocaleDateString()}</span>
            </div>
            <button className="p-2 text-slate-400 hover:text-slate-900 transition-colors">
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            {activeTab === 'home' && <AdminDashboard key="admin-dashboard" setActiveTab={setActiveTab} />}
            {activeTab === 'history' && <ComplaintHistory key="history" role="admin" uid={user.uid} />}
            {activeTab === 'pending' && <ComplaintHistory key="pending" role="admin" uid={user.uid} initialFilter="Pending" />}
            {activeTab === 'resolved' && <ComplaintHistory key="resolved" role="admin" uid={user.uid} initialFilter="Resolved" />}
            {activeTab === 'map' && <MapView key="map" />}
            {activeTab === 'analytics' && <AnalyticsView key="analytics" />}
            {activeTab === 'chat' && <ChatInterface key="chat" />}
            {activeTab === 'budget' && <BudgetView key="budget" />}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

function AdminNavLink({ icon: Icon, label, active, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
        active 
          ? "bg-slate-900 text-white shadow-lg shadow-slate-900/20" 
          : "text-slate-400 hover:text-white hover:bg-slate-800"
      )}
    >
      <Icon className={cn("w-5 h-5", active ? "text-white" : "group-hover:scale-110 transition-transform")} />
      <span className="font-medium text-sm">{label}</span>
      {active && <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 bg-white rounded-full" />}
    </button>
  );
}

function AdminVerification({ profile, onVerified }: { profile: UserProfile, onVerified: () => void }) {
  const [docs, setDocs] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploading(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        setDocs(prev => [...prev, reader.result as string]);
        setUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (docs.length === 0) return;
    try {
      await updateDoc(doc(db, 'users', profile.uid), {
        adminDocs: docs,
        // For demo purposes, we'll auto-verify after submission
        isAdminVerified: true,
        verificationStatus: 'approved'
      });
      onVerified();
    } catch (error) {
      console.error("Verification failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShieldCheck className="w-8 h-8 text-slate-900" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Admin Verification</h2>
        <p className="text-gray-500 mb-8">Please upload essential documents (ID, Authorization) to access the admin dashboard.</p>
        
        <div className="space-y-4 mb-8">
          {docs.map((d, i) => (
            <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <FileText className="w-5 h-5 text-gray-400" />
              <span className="text-sm text-gray-600 flex-1 text-left truncate">Document_{i+1}.pdf</span>
              <button onClick={() => setDocs(prev => prev.filter((_, idx) => idx !== i))} className="text-red-500">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
          
          <label className="block">
            <div className="w-full py-4 border-2 border-dashed border-gray-300 rounded-xl hover:border-slate-900 transition-colors cursor-pointer flex flex-col items-center">
              {uploading ? <Loader2 className="w-6 h-6 animate-spin text-slate-900" /> : <Upload className="w-6 h-6 text-gray-400" />}
              <span className="text-sm text-gray-500 mt-2">Click to upload document</span>
            </div>
            <input type="file" className="hidden" onChange={handleUpload} />
          </label>
        </div>

        <Button onClick={handleSubmit} disabled={docs.length === 0} className="w-full py-3">
          Submit for Verification
        </Button>
      </Card>
    </div>
  );
}

function ChatInterface() {
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: 'Hello! I am JANHITH AI. How can I help you today with civic issues or using the platform?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      const response = await getChatResponse(userMsg, history);
      setMessages(prev => [...prev, { role: 'model', text: response || 'Sorry, I encountered an error.' }]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: 'model', text: 'I am having trouble connecting right now. Please try again later.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="h-[calc(100vh-12rem)] flex flex-col overflow-hidden">
      <div className="p-4 border-b border-gray-100 flex items-center gap-3 bg-slate-900 text-white">
        <div className="bg-white/20 p-2 rounded-lg">
          <MessageSquare className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-bold">JANHITH AI Assistant</h3>
          <p className="text-xs opacity-80">Always active to help you</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
            <div className={cn(
              'max-w-[80%] p-3 rounded-2xl text-sm',
              m.role === 'user' ? 'bg-slate-900 text-white rounded-tr-none' : 'bg-gray-100 text-gray-800 rounded-tl-none'
            )}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 p-3 rounded-2xl rounded-tl-none">
              <Loader2 className="w-4 h-4 animate-spin text-slate-900" />
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="p-4 border-t border-gray-100 flex gap-2">
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask anything..."
          className="flex-1 px-4 py-2 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-slate-900"
        />
        <Button onClick={handleSend} disabled={!input.trim() || loading}>
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}

function NavLinks({ profile, activeTab, setActiveTab, isMobile }: any) {
  const links = [
    { id: 'home', label: 'Home', icon: LayoutDashboard, roles: ['citizen', 'admin', 'worker'] },
    { id: 'report', label: 'Report Issue', icon: Plus, roles: ['citizen'] },
    { id: 'pending', label: 'Pending', icon: Clock, roles: ['admin'] },
    { id: 'resolved', label: 'Resolved', icon: CheckCircle, roles: ['admin'] },
    { id: 'history', label: 'My Complaints', icon: History, roles: ['citizen'] },
    { id: 'history', label: 'All Complaints', icon: History, roles: ['admin'] },
    { id: 'map', label: 'Map View', icon: MapIcon, roles: ['admin', 'citizen'] },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: ['admin'] },
    { id: 'chat', label: 'AI Assistant', icon: MessageSquare, roles: ['admin', 'citizen', 'worker'] },
  ];

  return (
    <div className={cn('flex', isMobile ? 'flex-col space-y-1' : 'space-x-1')}>
      {links.filter(link => link.roles.includes(profile?.role)).map((link) => (
        <button
          key={link.id}
          onClick={() => setActiveTab(link.id)}
          className={cn(
            'flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all',
            activeTab === link.id 
              ? 'bg-slate-100 text-slate-700' 
              : 'text-gray-600 hover:bg-gray-100'
          )}
        >
          <link.icon className="w-4 h-4" />
          {link.label}
        </button>
      ))}
    </div>
  );
}

// --- Views ---

function LandingPage({ 
  onLogin, t, language, theme, toggleLanguage, toggleTheme,
  isCitizenRegistering, setIsCitizenRegistering,
  citizenEmail, setCitizenEmail,
  citizenPassword, setCitizenPassword,
  citizenName, setCitizenName,
  citizenError, handleCitizenLogin, handleCitizenRegister,
  deferredPrompt, handleInstallClick
}: any) {
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [error, setError] = useState('');
  const [isFirstTime, setIsFirstTime] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  useEffect(() => {
    const checkAdminConfig = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'config', 'admin'));
        if (!docSnap.exists()) {
          setIsFirstTime(true);
        }
      } catch (err) {
        console.error("Error checking admin config:", err);
      }
    };
    checkAdminConfig();
  }, []);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const docSnap = await getDoc(doc(db, 'config', 'admin'));
      if (docSnap.exists()) {
        const storedPassword = docSnap.data().password;
        if (adminPassword === storedPassword) {
          onLogin('admin');
        } else {
          setError('Invalid admin password');
        }
      } else {
        setError('Admin configuration missing. Please set up the password first.');
      }
    } catch (err) {
      setError('Failed to authenticate. Please try again.');
    }
  };

  const handleSetInitialPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    try {
      await setDoc(doc(db, 'config', 'admin'), {
        password: newPassword,
        createdAt: new Date().toISOString()
      });
      onLogin('admin');
    } catch (err) {
      setError('Failed to set password');
    }
  };

  const handleForgotPassword = async () => {
    setIsResetting(true);
    setError('');
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result.user.email === '237r1a66q2@cmrtc.ac.in') {
        await updateDoc(doc(db, 'config', 'admin'), {
          password: newPassword,
          lastResetAt: new Date().toISOString()
        });
        onLogin('admin');
      } else {
        setError('Unauthorized: Only the primary admin can reset the password.');
        await signOut(auth);
      }
    } catch (err) {
      setError('Reset failed');
    }
  };

  return (
    <div className={cn(
      "min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden transition-colors duration-500",
      theme === 'dark' ? "bg-slate-950" : "bg-slate-50"
    )}>
      {/* Background Decorations */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-slate-400 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-slate-400 rounded-full blur-[120px]" />
      </div>

      {/* Language & Theme Toggles */}
      <div className="absolute top-6 right-6 flex items-center gap-3 z-50">
        <button 
          onClick={toggleLanguage}
          className="p-2 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-gray-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all"
        >
          <Languages className="w-5 h-5 text-slate-900 dark:text-slate-400" />
        </button>
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border border-gray-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all"
        >
          {theme === 'light' ? <Moon className="w-5 h-5 text-slate-700" /> : <Sun className="w-5 h-5 text-yellow-400" />}
        </button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl w-full text-center relative z-10"
      >
        <div className="mb-12">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="w-24 h-24 bg-slate-900 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-slate-900/40 rotate-12"
          >
            <ShieldCheck className="w-12 h-12 text-white" />
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-6xl font-black text-slate-900 dark:text-white mb-6 tracking-tight"
          >
            {t.appName}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed"
          >
            {t.tagline}
          </motion.p>
          {deferredPrompt ? (
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="mt-8"
            >
              <Button 
                onClick={handleInstallClick} 
                className="mx-auto bg-emerald-600 hover:bg-emerald-700 text-white px-10 py-5 text-xl rounded-2xl shadow-2xl shadow-emerald-200 animate-bounce flex items-center gap-3"
              >
                <Zap className="w-6 h-6 fill-current" /> Install Mobile App (One-Click)
              </Button>
              <p className="text-xs text-emerald-600 font-bold mt-3 uppercase tracking-widest">Instant APK-like Experience</p>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-8 p-4 bg-slate-100 dark:bg-slate-800/50 rounded-2xl inline-block"
            >
              <p className="text-sm text-slate-600 dark:text-slate-400 flex items-center gap-2">
                <Info className="w-4 h-4" /> 
                To install as an app: Tap <b>Share</b> then <b>'Add to Home Screen'</b>
              </p>
            </motion.div>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl p-8 rounded-3xl border border-white/20 dark:border-slate-800 shadow-2xl shadow-slate-900/10"
          >
            <div className="w-14 h-14 bg-slate-100 dark:bg-slate-800/30 rounded-2xl flex items-center justify-center mb-6">
              <User className="w-7 h-7 text-slate-900 dark:text-slate-400" />
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">{t.citizenHome}</h2>
            <p className="text-slate-600 dark:text-slate-400 mb-8">Report issues, track progress, and help improve your neighborhood.</p>
            
            <div className="space-y-4">
              <AnimatePresence mode="wait">
                {isCitizenRegistering ? (
                  <motion.form
                    key="register"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    onSubmit={handleCitizenRegister}
                    className="space-y-3"
                  >
                    <input 
                      type="text"
                      placeholder="Full Name"
                      value={citizenName}
                      onChange={(e) => setCitizenName(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 outline-none"
                      required
                    />
                    <input 
                      type="email"
                      placeholder="Email Address"
                      value={citizenEmail}
                      onChange={(e) => setCitizenEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 outline-none"
                      required
                    />
                    <input 
                      type="password"
                      placeholder="Password"
                      value={citizenPassword}
                      onChange={(e) => setCitizenPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 outline-none"
                      required
                    />
                    {citizenError && <p className="text-red-500 text-xs text-left">{citizenError}</p>}
                    <Button type="submit" className="w-full py-3 bg-slate-900 hover:bg-slate-800">Create Account</Button>
                    <button 
                      type="button" 
                      onClick={() => setIsCitizenRegistering(false)}
                      className="text-slate-900 dark:text-slate-400 text-sm hover:underline"
                    >
                      Already have an account? Sign In
                    </button>
                  </motion.form>
                ) : (
                  <motion.form
                    key="login"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    onSubmit={handleCitizenLogin}
                    className="space-y-3"
                  >
                    <input 
                      type="email"
                      placeholder="Email Address"
                      value={citizenEmail}
                      onChange={(e) => setCitizenEmail(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 outline-none"
                      required
                    />
                    <input 
                      type="password"
                      placeholder="Password"
                      value={citizenPassword}
                      onChange={(e) => setCitizenPassword(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-slate-900 outline-none"
                      required
                    />
                    {citizenError && <p className="text-red-500 text-xs text-left">{citizenError}</p>}
                    <Button type="submit" className="w-full py-3 bg-slate-900 hover:bg-slate-800">Sign In</Button>
                    <div className="flex justify-between items-center">
                      <button 
                        type="button" 
                        onClick={() => setIsCitizenRegistering(true)}
                        className="text-slate-900 dark:text-slate-400 text-sm hover:underline"
                      >
                        New here? Register
                      </button>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-gray-200 dark:border-slate-800"></div></div>
                <div className="relative flex justify-center text-xs uppercase"><span className="bg-white dark:bg-slate-900 px-2 text-slate-500">Or continue with</span></div>
              </div>

              <Button 
                onClick={() => onLogin('citizen')}
                variant="outline"
                className="w-full py-3 border-gray-200 dark:border-slate-700 text-slate-900 dark:text-white hover:bg-gray-50 dark:hover:bg-slate-800"
              >
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5 mr-2" alt="Google" />
                Sign in with Google
              </Button>
            </div>
          </motion.div>

          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-slate-900/90 dark:bg-slate-900/80 backdrop-blur-xl p-8 rounded-3xl border border-slate-800 shadow-2xl shadow-slate-950/20"
          >
            <div className="w-14 h-14 bg-slate-800 rounded-2xl flex items-center justify-center mb-6">
              <Building2 className="w-7 h-7 text-slate-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">{t.adminDashboard}</h2>
            <p className="text-slate-400 mb-8">Manage reports, assign teams, and analyze city-wide civic data.</p>
            
            <AnimatePresence mode="wait">
              {!showAdminLogin ? (
                <motion.div
                  key="options"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <Button 
                    variant="outline"
                    onClick={() => setShowAdminLogin(true)}
                    className="w-full py-4 text-lg font-bold border-slate-700 text-white hover:bg-slate-800"
                  >
                    Admin Portal Login
                  </Button>
                </motion.div>
              ) : isFirstTime ? (
                <motion.form
                  key="setup"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  onSubmit={handleSetInitialPassword}
                  className="space-y-4"
                >
                  <div className="bg-slate-500/10 border border-slate-500/20 p-3 rounded-xl mb-4">
                    <p className="text-xs text-slate-400 flex items-center gap-2">
                      <Zap className="w-4 h-4" /> First-time setup: Create master password
                    </p>
                  </div>
                  <input 
                    type="password"
                    placeholder="New Master Password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-slate-900 outline-none"
                    required
                  />
                  <input 
                    type="password"
                    placeholder="Confirm Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-slate-900 outline-none"
                    required
                  />
                  {error && <p className="text-red-400 text-xs text-left">{error}</p>}
                  <Button type="submit" className="w-full py-3 bg-slate-900 hover:bg-slate-800">Set Password & Login</Button>
                  <button type="button" onClick={() => setShowAdminLogin(false)} className="text-slate-400 text-sm hover:text-white">Cancel</button>
                </motion.form>
              ) : isResetting ? (
                <motion.form
                  key="reset"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  onSubmit={handleResetPassword}
                  className="space-y-4"
                >
                  <div className="bg-red-500/10 border border-red-500/20 p-3 rounded-xl mb-4">
                    <p className="text-xs text-red-400 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4" /> Identity verification required
                    </p>
                  </div>
                  <input 
                    type="password"
                    placeholder="New Password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-slate-900 outline-none"
                    required
                  />
                  <input 
                    type="password"
                    placeholder="Confirm New Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-slate-900 outline-none"
                    required
                  />
                  {error && <p className="text-red-400 text-xs text-left">{error}</p>}
                  <Button type="submit" className="w-full py-3 bg-red-600 hover:bg-red-700">Verify Identity & Reset</Button>
                  <button type="button" onClick={() => setIsResetting(false)} className="text-slate-400 text-sm hover:text-white">Back to Login</button>
                </motion.form>
              ) : (
                <motion.form
                  key="login"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  onSubmit={handleAdminLogin}
                  className="space-y-4"
                >
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                    <input 
                      type="password"
                      placeholder="Master Password"
                      value={adminPassword}
                      onChange={(e) => setAdminPassword(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white focus:ring-2 focus:ring-slate-900 outline-none"
                      required
                    />
                  </div>
                  {error && <p className="text-red-400 text-xs text-left">{error}</p>}
                  <Button type="submit" className="w-full py-3 bg-slate-900 hover:bg-slate-800">Verify & Enter</Button>
                  <div className="flex justify-between items-center px-1">
                    <button type="button" onClick={handleForgotPassword} className="text-slate-400 text-xs hover:underline">Forgot Password?</button>
                    <button type="button" onClick={() => setShowAdminLogin(false)} className="text-slate-400 text-xs hover:text-white">Go Back</button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </motion.div>

      <div className="mt-16 flex gap-8 text-slate-400 dark:text-slate-500 text-sm font-medium">
        <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Real-time Tracking</span>
        <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> AI-Powered Analysis</span>
        <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Map Integration</span>
      </div>
      
      <div className="mt-12 text-center">
        <a 
          href={`https://www.webintoapp.com/convert?url=${encodeURIComponent(window.location.href)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-slate-400 hover:text-slate-600 text-xs underline underline-offset-4 transition-colors"
        >
          Need a traditional APK file? Click here for 1-Click Generation
        </a>
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc }: any) {
  return (
    <div className="bg-white/5 p-6 rounded-2xl border border-white/10">
      <Icon className="w-8 h-8 text-slate-300 mb-4" />
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-slate-400 text-sm">{desc}</p>
    </div>
  );
}

function CitizenHome({ setActiveTab }: { setActiveTab: (t: string) => void }) {
  const [stats, setStats] = useState({ pending: 0, resolved: 0 });
  const [recent, setRecent] = useState<Complaint[]>([]);

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, 'complaints'), 
      where('reporterUid', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc')
    );
    return onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint));
      setRecent(data.slice(0, 3));
      setStats({
        pending: data.filter(c => c.status !== 'Resolved').length,
        resolved: data.filter(c => c.status === 'Resolved').length
      });
    });
  }, []);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white border-none shadow-xl shadow-slate-900/20">
          <h2 className="text-lg font-medium opacity-90 mb-1">Active Complaints</h2>
          <p className="text-4xl font-bold">{stats.pending}</p>
          <div className="mt-4 flex items-center gap-2 text-sm opacity-80">
            <Clock className="w-4 h-4" />
            <span>Awaiting resolution</span>
          </div>
        </Card>
        <Card className="p-6 bg-gradient-to-br from-emerald-500 to-emerald-600 text-white border-none shadow-xl shadow-emerald-500/20">
          <h2 className="text-lg font-medium opacity-90 mb-1">Resolved Issues</h2>
          <p className="text-4xl font-bold">{stats.resolved}</p>
          <div className="mt-4 flex items-center gap-2 text-sm opacity-80">
            <CheckCircle className="w-4 h-4" />
            <span>Community improved</span>
          </div>
        </Card>
      </div>

      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-gray-900">Recent Reports</h3>
          <Button variant="ghost" className="text-slate-900" onClick={() => setActiveTab('history')}>View All</Button>
        </div>
        <div className="space-y-4">
          {recent.length > 0 ? recent.map(complaint => (
            <ComplaintCard key={complaint.id} complaint={complaint} />
          )) : (
            <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
              <History className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No complaints reported yet.</p>
              <Button onClick={() => setActiveTab('report')} className="mt-4">Report New Issue</Button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function ReportIssue({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(1);
  const [image, setImage] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState<{ lat: number, lng: number, address: string } | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      console.error("Camera error:", err);
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = videoRef.current.videoWidth;
      canvasRef.current.height = videoRef.current.videoHeight;
      context?.drawImage(videoRef.current, 0, 0);
      const data = canvasRef.current.toDataURL('image/jpeg');
      setImage(data);
      // Stop stream
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const getLocation = () => {
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude, longitude } = pos.coords;
      // In a real app, use reverse geocoding here
      setLocation({ lat: latitude, lng: longitude, address: "Fetching address..." });
      // Mock address for now
      setTimeout(() => setLocation({ lat: latitude, lng: longitude, address: `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}` }), 1000);
    });
  };

  const handleAnalyze = async () => {
    if (!image || !description) return;
    setAnalyzing(true);
    try {
      const result = await analyzeCivicIssue(image, description);
      setAnalysis(result);
      setStep(2);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSubmit = async () => {
    if (!auth.currentUser || !analysis || !location) return;
    setSubmitting(true);
    try {
      const complaintData: Partial<Complaint> = {
        reporterUid: auth.currentUser.uid,
        reporterName: auth.currentUser.displayName || 'Anonymous',
        type: analysis.type as ComplaintType,
        description,
        imageUrl: image || '',
        location: {
          latitude: location.lat,
          longitude: location.lng,
          address: location.address,
        },
        status: 'Pending',
        priority: analysis.priority as Priority,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        aiAnalysis: {
          detectedType: analysis.type,
          confidence: 0.95,
          urgency: analysis.urgency || 'Normal',
          reasoning: analysis.reasoning || '',
        }
      };
      await addDoc(collection(db, 'complaints'), complaintData);
      onComplete();
    } catch (error) {
      console.error("Submission failed:", error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <div className="p-6 border-b border-gray-100 flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-900">Report New Issue</h2>
        <div className="flex gap-1">
          {[1, 2, 3].map(i => (
            <div key={i} className={cn('h-1.5 w-8 rounded-full transition-all', step >= i ? 'bg-slate-900' : 'bg-gray-200')} />
          ))}
        </div>
      </div>

      <div className="p-6">
        {step === 1 && (
          <div className="space-y-6">
            <div className="relative aspect-video bg-black rounded-xl overflow-hidden group">
              {!image ? (
                <>
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                    <Button onClick={startCamera} className="bg-white/20 backdrop-blur-md border-white/30 text-white hover:bg-white/30">
                      <Camera className="w-5 h-5" /> Start Camera
                    </Button>
                    <div className="flex items-center gap-2 w-full px-12">
                      <div className="h-px bg-white/20 flex-1" />
                      <span className="text-white/50 text-xs font-medium">OR</span>
                      <div className="h-px bg-white/20 flex-1" />
                    </div>
                    <Button onClick={() => fileInputRef.current?.click()} className="bg-white/20 backdrop-blur-md border-white/30 text-white hover:bg-white/30">
                      <Upload className="w-5 h-5" /> Upload Photo
                    </Button>
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      onChange={handleFileUpload} 
                      accept="image/*" 
                      className="hidden" 
                    />
                  </div>
                  <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                    <button onClick={captureImage} className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center hover:scale-110 transition-transform">
                      <div className="w-12 h-12 bg-white rounded-full" />
                    </button>
                  </div>
                </>
              ) : (
                <img src={image} className="w-full h-full object-cover" alt="Captured" />
              )}
              <canvas ref={canvasRef} className="hidden" />
            </div>
            {image && (
              <Button onClick={() => setImage(null)} variant="outline" className="w-full">
                Retake Photo
              </Button>
            )}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Description</label>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the issue in detail..."
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-slate-900 focus:border-transparent outline-none h-32 resize-none"
              />
            </div>
            <Button 
              onClick={handleAnalyze} 
              disabled={!image || !description || analyzing} 
              className="w-full py-4 text-lg"
            >
              {analyzing ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Analyze with AI'}
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-slate-900 p-2 rounded-lg">
                  <Construction className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-bold text-slate-900">AI Analysis Result</h3>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Issue Type</p>
                  <p className="font-semibold text-gray-900">{analysis?.type}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Priority</p>
                  <Badge variant={analysis?.priority === 'Critical' ? 'danger' : 'warning'}>{analysis?.priority}</Badge>
                </div>
              </div>
              <div>
                <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Reasoning</p>
                <p className="text-sm text-gray-700 leading-relaxed">{analysis?.reasoning}</p>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-bold text-gray-900">Location Tagging</h3>
              <div className="flex items-center gap-4 p-4 rounded-xl border border-gray-200 bg-gray-50">
                <div className="bg-white p-2 rounded-lg border border-gray-200">
                  <MapPin className="w-6 h-6 text-slate-900" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{location?.address || 'Location not set'}</p>
                  <p className="text-xs text-gray-500">Auto-tagged via GPS</p>
                </div>
                <Button onClick={getLocation} variant="outline" className="px-3 py-1 text-xs">
                  {location ? 'Refresh' : 'Get Location'}
                </Button>
              </div>
            </div>

            <div className="flex gap-4">
              <Button onClick={() => setStep(1)} variant="outline" className="flex-1">Back</Button>
              <Button onClick={() => setStep(3)} disabled={!location} className="flex-1">Continue</Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="text-center space-y-6 py-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-900">Ready to Submit</h3>
              <p className="text-gray-500 mt-2">Your report will be sent to the municipal authorities for immediate action.</p>
            </div>
            <div className="flex gap-4 pt-4">
              <Button onClick={() => setStep(2)} variant="outline" className="flex-1">Review</Button>
              <Button onClick={handleSubmit} disabled={submitting} className="flex-1">
                {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Submit Report'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}

function ComplaintHistory({ role, uid, initialFilter = 'All' }: { role?: UserRole, uid: string, initialFilter?: string }) {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [filter, setFilter] = useState(initialFilter);
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [locationFilter, setLocationFilter] = useState('');

  useEffect(() => {
    setFilter(initialFilter);
  }, [initialFilter]);

  useEffect(() => {
    let q;
    if (role === 'admin') {
      q = query(collection(db, 'complaints'), orderBy('createdAt', 'desc'));
    } else {
      q = query(collection(db, 'complaints'), where('reporterUid', '==', uid), orderBy('createdAt', 'desc'));
    }
    return onSnapshot(q, (snapshot) => {
      setComplaints(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint)));
    });
  }, [role, uid]);

  const filtered = complaints.filter(c => {
    const statusMatch = filter === 'All' || c.status === filter;
    const categoryMatch = categoryFilter === 'All' || c.type === categoryFilter;
    const locationMatch = !locationFilter || c.location.address.toLowerCase().includes(locationFilter.toLowerCase());
    return statusMatch && categoryMatch && locationMatch;
  });

  const categories = ['All', 'Pothole', 'Garbage', 'Water Leakage', 'Streetlight Failure', 'Other'];

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <h2 className="text-2xl font-bold text-gray-900">{role === 'admin' ? 'All Complaints' : 'My History'}</h2>
        
        <div className="flex flex-wrap gap-4 items-center">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text" 
              placeholder="Filter by location..." 
              value={locationFilter}
              onChange={(e) => setLocationFilter(e.target.value)}
              className="pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-slate-900 w-full md:w-64"
            />
          </div>

          <select 
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
          >
            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>

          <div className="flex gap-1 bg-gray-100 p-1 rounded-xl">
            {['All', 'Pending', 'In Progress', 'Resolved'].map(s => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={cn(
                  'px-4 py-1.5 rounded-lg text-xs font-bold transition-all',
                  filter === s ? 'bg-white text-slate-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filtered.length > 0 ? filtered.map(complaint => (
          <ComplaintCard key={complaint.id} complaint={complaint} isAdmin={role === 'admin'} />
        )) : (
          <div className="text-center py-20 bg-white rounded-2xl border border-gray-200">
            <History className="w-16 h-16 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-500">No complaints found matching the filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ComplaintCard({ complaint, isAdmin = false, isWorker = false }: { complaint: Complaint, isAdmin?: boolean, isWorker?: boolean }) {
  const [updating, setUpdating] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [showPhoto, setShowPhoto] = useState(false);
  const [showAssign, setShowAssign] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [workers, setWorkers] = useState<UserProfile[]>([]);

  useEffect(() => {
    if (isAdmin && showAssign) {
      const q = query(collection(db, 'users'), where('role', '==', 'worker'));
      return onSnapshot(q, (snapshot) => {
        setWorkers(snapshot.docs.map(doc => doc.data() as UserProfile));
      });
    }
  }, [isAdmin, showAssign]);

  const addComment = async () => {
    if (!newComment.trim() || !auth.currentUser) return;
    setUpdating(true);
    try {
      const comment: ComplaintComment = {
        uid: auth.currentUser.uid,
        userName: auth.currentUser.displayName || 'Anonymous',
        text: newComment,
        createdAt: new Date().toISOString()
      };
      
      await updateDoc(doc(db, 'complaints', complaint.id), {
        comments: arrayUnion(comment),
        updatedAt: new Date().toISOString()
      });
      setNewComment('');
    } catch (error) {
      console.error("Comment failed:", error);
    } finally {
      setUpdating(false);
    }
  };

  const updateStatus = async (newStatus: ComplaintStatus) => {
    setUpdating(true);
    try {
      await updateDoc(doc(db, 'complaints', complaint.id), { 
        status: newStatus,
        updatedAt: new Date().toISOString()
      });
      
      // Add notification for the user
      await addDoc(collection(db, 'notifications'), {
        uid: complaint.reporterUid,
        title: 'Status Updated',
        message: `Your ${complaint.type} report status has been changed to ${newStatus}.`,
        complaintId: complaint.id,
        isRead: false,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Update failed:", error);
    } finally {
      setUpdating(false);
    }
  };

  const assignWorker = async (workerUid: string, workerName: string) => {
    setUpdating(true);
    try {
      await updateDoc(doc(db, 'complaints', complaint.id), { 
        assignedTo: workerUid,
        status: 'Assigned',
        updatedAt: new Date().toISOString()
      });
      
      // Notify worker
      await addDoc(collection(db, 'notifications'), {
        uid: workerUid,
        title: 'New Task Assigned',
        message: `You have been assigned a new ${complaint.type} task at ${complaint.location.address}.`,
        complaintId: complaint.id,
        isRead: false,
        createdAt: new Date().toISOString()
      });

      setShowAssign(false);
    } catch (error) {
      console.error("Assignment failed:", error);
    } finally {
      setUpdating(false);
    }
  };

  const statusColors = {
    'Pending': 'warning',
    'Assigned': 'info',
    'In Progress': 'info',
    'Resolved': 'success',
    'Rejected': 'danger'
  };

  const priorityColors = {
    'Low': 'default',
    'Medium': 'info',
    'High': 'warning',
    'Critical': 'danger'
  };

  return (
    <>
      <Card className="flex flex-col md:flex-row group hover:shadow-md transition-shadow">
        <div className="w-full md:w-48 h-48 flex-shrink-0 relative overflow-hidden">
          <img 
            src={complaint.imageUrl || 'https://picsum.photos/seed/issue/400/400'} 
            className="w-full h-full object-cover transition-transform group-hover:scale-105" 
            alt="Issue" 
            referrerPolicy="no-referrer"
          />
          <button 
            onClick={() => setShowPhoto(true)}
            className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white gap-2 text-sm font-medium"
          >
            <ImageIcon className="w-5 h-5" /> View Photo
          </button>
        </div>
        <div className="p-6 flex-1 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-2">
              <div className="flex flex-wrap gap-2">
                <Badge variant={statusColors[complaint.status as keyof typeof statusColors]}>{complaint.status}</Badge>
                <Badge variant={priorityColors[complaint.priority as keyof typeof priorityColors]}>{complaint.priority} Priority</Badge>
              </div>
              <p className="text-xs text-gray-400">{new Date(complaint.createdAt).toLocaleDateString()}</p>
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-1">{complaint.type}</h3>
            <p className="text-sm text-gray-600 line-clamp-2 mb-4">{complaint.description}</p>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <div className="flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                <span className="truncate max-w-[150px]">{complaint.location.address}</span>
              </div>
              {isAdmin && (
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  <span>{complaint.reporterName}</span>
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-gray-100 flex flex-wrap items-center gap-3">
            {isAdmin ? (
              <>
                <select 
                  className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                  value={complaint.status}
                  onChange={(e) => updateStatus(e.target.value as ComplaintStatus)}
                  disabled={updating}
                >
                  <option value="Pending">Pending</option>
                  <option value="Assigned">Assigned</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                  <option value="Rejected">Rejected</option>
                </select>
                <Button 
                  variant="outline" 
                  className="text-xs py-1.5"
                  onClick={() => setShowAssign(true)}
                  disabled={updating}
                >
                  <Users className="w-3.5 h-3.5" /> Assign Worker
                </Button>
              </>
            ) : isWorker ? (
              <div className="flex gap-2">
                <Button 
                  onClick={() => updateStatus('In Progress')}
                  disabled={updating || complaint.status === 'In Progress'}
                  className="text-xs py-1.5 bg-slate-900"
                >
                  Start Work
                </Button>
                <Button 
                  onClick={() => updateStatus('Resolved')}
                  disabled={updating || complaint.status === 'Resolved'}
                  className="text-xs py-1.5 bg-emerald-600"
                >
                  Mark Resolved
                </Button>
                <Button 
                  variant="outline" 
                  className="text-xs py-1.5"
                  onClick={() => setShowDetails(true)}
                >
                  <Info className="w-3.5 h-3.5" /> Details
                </Button>
              </div>
            ) : (
              <Button 
                variant="outline" 
                className="text-xs py-1.5"
                onClick={() => setShowDetails(true)}
              >
                <Info className="w-3.5 h-3.5" /> View Details
              </Button>
            )}
            <Button 
              variant="ghost" 
              className="text-xs py-1.5 ml-auto text-gray-400 hover:text-slate-900"
              onClick={() => setShowComments(true)}
            >
              <MessageCircle className="w-4 h-4" />
              {complaint.comments && complaint.comments.length > 0 && (
                <span className="ml-1 font-bold">{complaint.comments.length}</span>
              )}
            </Button>
          </div>
        </div>
      </Card>

      {/* Photo Modal */}
      <AnimatePresence>
        {showPhoto && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative max-w-4xl w-full aspect-video rounded-2xl overflow-hidden shadow-2xl"
            >
              <img 
                src={complaint.imageUrl || 'https://picsum.photos/seed/issue/1200/800'} 
                className="w-full h-full object-contain bg-black" 
                alt="Full view" 
                referrerPolicy="no-referrer"
              />
              <button 
                onClick={() => setShowPhoto(false)}
                className="absolute top-4 right-4 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur-md transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Details Modal */}
      <AnimatePresence>
        {showDetails && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden border border-gray-100"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <h3 className="text-xl font-bold text-gray-900">Complaint Details</h3>
                <button onClick={() => setShowDetails(false)} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-8 space-y-6 max-h-[70vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Status</p>
                    <Badge variant={statusColors[complaint.status as keyof typeof statusColors]}>{complaint.status}</Badge>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Priority</p>
                    <Badge variant={priorityColors[complaint.priority as keyof typeof priorityColors]}>{complaint.priority}</Badge>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Reported On</p>
                    <p className="text-sm font-medium text-gray-900">{new Date(complaint.createdAt).toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Last Updated</p>
                    <p className="text-sm font-medium text-gray-900">{new Date(complaint.updatedAt).toLocaleString()}</p>
                  </div>
                </div>

                <div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Location</p>
                  <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl border border-gray-100">
                    <MapPin className="w-4 h-4 text-slate-900" />
                    <p className="text-sm font-medium text-gray-700">{complaint.location.address}</p>
                  </div>
                </div>

                <div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Description</p>
                  <p className="text-sm text-gray-700 leading-relaxed bg-gray-50 p-4 rounded-xl border border-gray-100">{complaint.description}</p>
                </div>

                {complaint.aiAnalysis && (
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                    <div className="flex items-center gap-2 mb-3">
                      <ShieldCheck className="w-5 h-5 text-slate-900" />
                      <h4 className="font-bold text-slate-900">AI Analysis Report</h4>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Detected Type:</span>
                        <span className="font-bold text-slate-900">{complaint.aiAnalysis.detectedType}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Confidence Score:</span>
                        <span className="font-bold text-slate-900">{(complaint.aiAnalysis.confidence * 100).toFixed(1)}%</span>
                      </div>
                      <div className="pt-2 border-t border-slate-200">
                        <p className="text-xs text-slate-500 font-bold uppercase mb-1">Reasoning</p>
                        <p className="text-xs text-slate-800 leading-relaxed italic">"{complaint.aiAnalysis.reasoning}"</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-end">
                <Button onClick={() => setShowDetails(false)} className="px-8">Close</Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Assign Worker Modal */}
      <AnimatePresence>
        {showAssign && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center">
                <h3 className="text-xl font-bold text-gray-900">Assign Worker</h3>
                <button onClick={() => setShowAssign(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
                {workers.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Users className="w-12 h-12 mx-auto mb-2 opacity-20" />
                    <p>No active workers found</p>
                  </div>
                ) : (
                  workers.map(worker => (
                    <button 
                      key={worker.uid}
                      onClick={() => assignWorker(worker.uid, worker.displayName)}
                      className="w-full flex items-center gap-4 p-4 rounded-2xl border border-gray-100 hover:border-slate-900 hover:bg-slate-50 transition-all text-left group"
                    >
                      <img src={worker.photoURL || `https://ui-avatars.com/api/?name=${worker.displayName}`} className="w-10 h-10 rounded-full border border-gray-200" alt="" />
                      <div className="flex-1">
                        <p className="font-bold text-gray-900 group-hover:text-slate-900 transition-colors">{worker.displayName}</p>
                        <p className="text-xs text-gray-500">Field Worker</p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-slate-900 transition-all" />
                    </button>
                  ))
                )}
              </div>
              <div className="p-6 bg-gray-50 border-t border-gray-100">
                <Button variant="outline" onClick={() => setShowAssign(false)} className="w-full">Cancel</Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Comments Modal */}
      <AnimatePresence>
        {showComments && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col h-[600px]"
            >
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <h3 className="text-xl font-bold text-gray-900">Comments</h3>
                <button onClick={() => setShowComments(false)} className="p-2 hover:bg-gray-200 rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex-1 p-6 space-y-4 overflow-y-auto">
                {!complaint.comments || complaint.comments.length === 0 ? (
                  <div className="text-center py-12 text-gray-400">
                    <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-20" />
                    <p>No comments yet. Be the first to start the conversation!</p>
                  </div>
                ) : (
                  complaint.comments.map((comment, idx) => (
                    <div key={idx} className={cn(
                      "flex flex-col gap-1 max-w-[85%]",
                      comment.uid === auth.currentUser?.uid ? "ml-auto items-end" : "mr-auto items-start"
                    )}>
                      <div className={cn(
                        "p-3 rounded-2xl text-sm",
                        comment.uid === auth.currentUser?.uid 
                          ? "bg-slate-900 text-white rounded-tr-none" 
                          : "bg-gray-100 text-gray-800 rounded-tl-none"
                      )}>
                        <p className="font-bold text-[10px] mb-1 opacity-70">{comment.userName}</p>
                        <p>{comment.text}</p>
                      </div>
                      <p className="text-[10px] text-gray-400">{new Date(comment.createdAt).toLocaleTimeString()}</p>
                    </div>
                  ))
                )}
              </div>

              <div className="p-6 bg-gray-50 border-t border-gray-100">
                <div className="flex gap-2">
                  <input 
                    type="text"
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Type a comment..."
                    className="flex-1 bg-white border border-gray-200 rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-900"
                    onKeyPress={(e) => e.key === 'Enter' && addComment()}
                  />
                  <Button 
                    onClick={addComment}
                    disabled={updating || !newComment.trim()}
                    className="bg-slate-900 rounded-xl px-4"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}

function AdminDashboard({ setActiveTab }: { setActiveTab: (t: string) => void }) {
  const [stats, setStats] = useState([
    { label: 'Total Complaints', value: 0, icon: Construction, color: 'text-slate-900', bg: 'bg-slate-50' },
    { label: 'Pending', value: 0, icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-50' },
    { label: 'Resolved', value: 0, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Active Workers', value: 0, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
  ]);

  const [chartData, setChartData] = useState<any[]>([]);
  const [severeIssues, setSevereIssues] = useState<Complaint[]>([]);
  const [showSeverePopup, setShowSeverePopup] = useState(false);

  useEffect(() => {
    const unsubComplaints = onSnapshot(collection(db, 'complaints'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint));
      const pending = data.filter(c => c.status !== 'Resolved').length;
      const resolved = data.filter(c => c.status === 'Resolved').length;
      
      setStats(prev => [
        { ...prev[0], value: data.length },
        { ...prev[1], value: pending },
        { ...prev[2], value: resolved },
        prev[3]
      ]);

      // Group by type for chart
      const types = ['Pothole', 'Garbage', 'Water Leakage', 'Streetlight Failure', 'Other'];
      const grouped = types.map(t => ({
        name: t,
        value: data.filter(c => c.type === t).length
      }));
      setChartData(grouped);

      // Find severe issues
      const severe = data.filter(c => (c.priority === 'Critical' || c.priority === 'High') && c.status === 'Pending');
      setSevereIssues(severe);
      if (severe.length > 0) {
        setShowSeverePopup(true);
      }
    });

    const unsubWorkers = onSnapshot(query(collection(db, 'users'), where('role', '==', 'worker')), (snapshot) => {
      setStats(prev => {
        const newStats = [...prev];
        newStats[3] = { ...newStats[3], value: snapshot.docs.length };
        return newStats;
      });
    });

    return () => {
      unsubComplaints();
      unsubWorkers();
    };
  }, []);

  const handleSolveImmediately = async (issue: Complaint) => {
    try {
      await updateDoc(doc(db, 'complaints', issue.id), {
        status: 'In Progress',
        updatedAt: new Date().toISOString()
      });
      // Add notification for the user
      await addDoc(collection(db, 'notifications'), {
        uid: issue.reporterUid,
        title: 'Team Dispatched!',
        message: `A rapid response team has been dispatched for your ${issue.type} report.`,
        complaintId: issue.id,
        isRead: false,
        createdAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Failed to update issue:", error);
    }
  };

  const quickActions = [
    { id: 'pending', label: 'Pending Issues', desc: 'Awaiting action', icon: Clock, color: 'bg-yellow-600' },
    { id: 'resolved', label: 'Resolved Issues', desc: 'Completed tasks', icon: CheckCircle, color: 'bg-emerald-600' },
    { id: 'history', label: 'Manage All', desc: 'Full history', icon: Zap, color: 'bg-slate-900' },
    { id: 'map', label: 'Live Map', desc: 'Hotspot tracking', icon: MapIcon, color: 'bg-slate-800' },
    { id: 'analytics', label: 'Reports', desc: 'Weekly analysis', icon: BarChart3, color: 'bg-amber-600' },
    { id: 'chat', label: 'AI Assistant', desc: 'Query data with AI', icon: MessageSquare, color: 'bg-blue-600' },
    { id: 'budget', label: 'Budget', desc: 'Fund allocation', icon: Building2, color: 'bg-slate-700', action: () => setActiveTab('budget') },
  ];

  return (
    <div className="space-y-8">
      {/* Severe Issues Popup */}
      <AnimatePresence>
        {showSeverePopup && severeIssues.length > 0 && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl w-full max-w-5xl overflow-hidden border border-red-500/20"
            >
              <div className="bg-gradient-to-r from-red-600 to-orange-600 p-8 text-white flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md animate-pulse">
                    <AlertTriangle className="w-8 h-8" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black tracking-tighter uppercase">Critical Issues Detected</h2>
                    <p className="text-red-100 font-medium">Immediate action required for {severeIssues.length} severe reports</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowSeverePopup(false)}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="p-8 max-h-[60vh] overflow-y-auto custom-scrollbar">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {severeIssues.map(issue => (
                    <div key={issue.id} className="bg-slate-50 dark:bg-slate-800/50 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 hover:border-red-500/30 transition-all group">
                      <div className="flex justify-between items-start mb-4">
                        <Badge variant="danger" className="px-4 py-1 text-sm font-bold uppercase tracking-widest">{issue.priority}</Badge>
                        <span className="text-xs font-mono text-slate-400">{new Date(issue.createdAt).toLocaleTimeString()}</span>
                      </div>
                      <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{issue.type}</h4>
                      <p className="text-slate-600 dark:text-slate-400 text-sm line-clamp-2 mb-6">{issue.description}</p>
                      
                      <div className="flex items-center gap-3 mb-6 p-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                        <MapPin className="w-5 h-5 text-red-500" />
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300 truncate">{issue.location.address}</span>
                      </div>

                      <div className="flex gap-3">
                        <Button 
                          onClick={() => handleSolveImmediately(issue)}
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-2xl shadow-lg shadow-red-600/20"
                        >
                          <Zap className="w-4 h-4" /> Send Team
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => {
                            setShowSeverePopup(false);
                            setActiveTab('history');
                          }}
                          className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold py-3 rounded-2xl"
                        >
                          Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="p-6 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-700 flex justify-end">
                <Button 
                  onClick={() => setShowSeverePopup(false)}
                  className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-black px-10 py-4 rounded-2xl"
                >
                  DISMISS OVERVIEW
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <Card 
            key={action.id}
            onClick={() => action.action ? action.action() : setActiveTab(action.id)}
            className={cn(
              "p-4 text-white flex items-center justify-between transition-all cursor-pointer group hover:scale-[1.02] active:scale-[0.98]",
              action.color
            )}
          >
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-xl">
                <action.icon className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold">{action.label}</h4>
                <p className="text-xs opacity-80">{action.desc}</p>
              </div>
            </div>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <Card key={i} className="p-6 flex items-center gap-4 border-none shadow-md">
            <div className={cn('p-4 rounded-2xl', stat.bg)}>
              <stat.icon className={cn('w-6 h-6', stat.color)} />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="p-6 border-none shadow-md">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Complaints by Type</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  cursor={{ fill: '#f3f4f6' }}
                />
                <Bar dataKey="value" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6 border-none shadow-md">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Resolution Status</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[
                    { name: 'Pending', value: stats[1].value },
                    { name: 'Resolved', value: stats[2].value }
                  ]}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  <Cell fill="#eab308" />
                  <Cell fill="#10b981" />
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
}

function MapView() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);

  useEffect(() => {
    return onSnapshot(collection(db, 'complaints'), (snapshot) => {
      setComplaints(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint)));
    });
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Issue Hotspots</h2>
        <Badge variant="info">{complaints.length} Issues Tracked</Badge>
      </div>
      <Card className="aspect-video relative bg-gray-100 flex items-center justify-center overflow-hidden">
        {/* Mock Map Background */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="grid grid-cols-12 h-full w-full">
            {Array.from({ length: 144 }).map((_, i) => (
              <div key={i} className="border border-gray-300" />
            ))}
          </div>
        </div>
        
        {/* Mock Map Markers */}
        <div className="relative w-full h-full">
          {complaints.map((c, i) => (
            <motion.div
              key={c.id}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="absolute"
              style={{ 
                left: `${(c.location.longitude % 1) * 10000 % 100}%`, 
                top: `${(c.location.latitude % 1) * 10000 % 100}%` 
              }}
            >
              <div className="group relative">
                <MapPin className={cn(
                  'w-6 h-6 drop-shadow-md cursor-pointer transition-transform hover:scale-125',
                  c.priority === 'Critical' ? 'text-red-600' : 
                  c.priority === 'High' ? 'text-orange-500' : 'text-slate-900'
                )} />
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-20">
                  <div className="bg-white p-3 rounded-xl shadow-xl border border-gray-100 w-48">
                    <p className="text-xs font-bold text-gray-400 uppercase mb-1">{c.type}</p>
                    <p className="text-sm font-semibold text-gray-900 line-clamp-1">{c.description}</p>
                    <div className="mt-2 flex justify-between items-center">
                      <Badge variant={c.status === 'Resolved' ? 'success' : 'warning'}>{c.status}</Badge>
                      <span className="text-[10px] text-gray-400">{new Date(c.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="absolute bottom-4 right-4 bg-white/80 backdrop-blur-md p-4 rounded-xl border border-white/50 shadow-lg text-xs space-y-2">
          <p className="font-bold text-gray-900 mb-2">Legend</p>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-600" /> <span>Critical Priority</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500" /> <span>High Priority</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-slate-900" /> <span>Normal Priority</span>
          </div>
        </div>
      </Card>
    </div>
  );
}

function AnalyticsView() {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    // Mock data for weekly trends
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const mockData = days.map(day => ({
      name: day,
      reported: Math.floor(Math.random() * 20) + 5,
      resolved: Math.floor(Math.random() * 15) + 2
    }));
    setData(mockData);
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Performance Analytics</h2>
        <Button variant="outline" className="text-sm">
          <Filter className="w-4 h-4" /> Last 7 Days
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-8">
        <Card className="p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Weekly Reporting vs Resolution Trend</h3>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="reported" stroke="#4f46e5" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="resolved" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <AnalyticsCard title="Avg. Resolution Time" value="4.2 Days" trend="-12%" trendType="good" />
          <AnalyticsCard title="Citizen Satisfaction" value="4.8/5" trend="+5%" trendType="good" />
          <AnalyticsCard title="Resource Efficiency" value="88%" trend="+2%" trendType="good" />
        </div>
      </div>
    </div>
  );
}

function AnalyticsCard({ title, value, trend, trendType }: any) {
  return (
    <Card className="p-6">
      <p className="text-sm font-medium text-gray-500 mb-1">{title}</p>
      <div className="flex items-end justify-between">
        <p className="text-3xl font-bold text-gray-900">{value}</p>
        <span className={cn(
          'text-xs font-bold px-2 py-1 rounded-lg',
          trendType === 'good' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
        )}>
          {trend}
        </span>
      </div>
    </Card>
  );
}

function WorkerTasks() {
  const [tasks, setTasks] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, 'complaints'), 
      where('assignedTo', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc')
    );
    return onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Complaint)));
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-slate-900 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">My Assigned Tasks</h2>
          <p className="text-gray-500">Manage your field work and update progress</p>
        </div>
        <Badge variant="info">{tasks.length} Active Tasks</Badge>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {tasks.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-gray-300">
            <CheckCircle className="w-16 h-16 text-green-100 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-gray-900">All caught up!</h3>
            <p className="text-gray-500">No tasks currently assigned to you.</p>
          </div>
        ) : (
          tasks.map(task => (
            <ComplaintCard key={task.id} complaint={task} isWorker />
          ))
        )}
      </div>
    </div>
  );
}

function BudgetView() {
  const [budgetData, setBudgetData] = useState([
    { type: 'Roads', allocated: 5000000, spent: 3200000 },
    { type: 'Sanitation', allocated: 3000000, spent: 2800000 },
    { type: 'Water', allocated: 4000000, spent: 1500000 },
    { type: 'Lighting', allocated: 2000000, spent: 1800000 },
    { type: 'Emergency', allocated: 1000000, spent: 400000 },
  ]);
  const [showSuccess, setShowSuccess] = useState(false);

  const addAllocation = () => {
    const types = ['Education', 'Healthcare', 'Parks', 'Public Transport', 'IT Infrastructure'];
    const type = types[Math.floor(Math.random() * types.length)];
    const exists = budgetData.find(b => b.type === type);
    if (exists) {
      setBudgetData(budgetData.map(b => b.type === type ? { ...b, allocated: b.allocated + 500000 } : b));
    } else {
      setBudgetData([...budgetData, { type, allocated: 1000000, spent: 0 }]);
    }
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const totalAllocated = budgetData.reduce((acc, curr) => acc + curr.allocated, 0);
  const totalSpent = budgetData.reduce((acc, curr) => acc + curr.spent, 0);
  const remaining = totalAllocated - totalSpent;

  return (
    <div className="space-y-8">
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-24 right-8 z-50 bg-emerald-600 text-white px-6 py-3 rounded-2xl shadow-xl flex items-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            <span className="font-bold">Budget Updated Successfully!</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Municipal Budget Allocation</h2>
          <p className="text-gray-500">Financial oversight and departmental funding</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" onClick={() => {
            setShowSuccess(true);
            setTimeout(() => setShowSuccess(false), 3000);
          }}>
            <FileText className="w-4 h-4" /> Export Report
          </Button>
          <Button onClick={addAllocation} className="bg-slate-900">
            <Plus className="w-4 h-4" /> New Allocation
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6 bg-slate-900 text-white shadow-lg shadow-slate-900/20">
          <p className="text-sm opacity-80 mb-1">Total Budget</p>
          <p className="text-3xl font-bold">₹{(totalAllocated / 10000000).toFixed(2)} Cr</p>
        </Card>
        <Card className="p-6 bg-emerald-600 text-white shadow-lg shadow-emerald-600/20">
          <p className="text-sm opacity-80 mb-1">Total Spent</p>
          <p className="text-3xl font-bold">₹{(totalSpent / 100000).toFixed(1)} L</p>
        </Card>
        <Card className="p-6 bg-amber-500 text-white shadow-lg shadow-amber-500/20">
          <p className="text-sm opacity-80 mb-1">Remaining</p>
          <p className="text-3xl font-bold">₹{(remaining / 100000).toFixed(1)} L</p>
        </Card>
      </div>

      <Card className="p-8">
        <h3 className="text-lg font-bold mb-6">Budget Utilization by Department</h3>
        <div className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={budgetData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" hide />
              <YAxis dataKey="type" type="category" width={100} axisLine={false} tickLine={false} />
              <Tooltip 
                formatter={(value: number) => `₹${(value / 100000).toFixed(1)} L`}
              />
              <Legend />
              <Bar dataKey="allocated" fill="#e2e8f0" radius={[0, 4, 4, 0]} name="Allocated" />
              <Bar dataKey="spent" fill="#4f46e5" radius={[0, 4, 4, 0]} name="Spent" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid grid-cols-1 gap-4">
        <h3 className="text-lg font-bold">Recent Transactions</h3>
        {budgetData.map((item, i) => (
          <Card key={i} className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gray-100 rounded-xl">
                <Building2 className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <p className="font-bold text-gray-900">{item.type} Maintenance</p>
                <p className="text-xs text-gray-500">Approved by Admin</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold text-slate-900">₹{(item.spent / 100000).toFixed(1)} L</p>
              <p className="text-[10px] text-gray-400">24 Mar 2026</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
