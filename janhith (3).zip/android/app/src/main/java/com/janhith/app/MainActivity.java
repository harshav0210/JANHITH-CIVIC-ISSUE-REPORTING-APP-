package com.janhith.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
