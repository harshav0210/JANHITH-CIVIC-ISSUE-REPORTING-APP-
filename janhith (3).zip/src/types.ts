export type UserRole = 'citizen' | 'worker' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: UserRole;
  createdAt: string;
  isAdminVerified?: boolean;
  adminDocs?: string[];
  verificationStatus?: 'pending' | 'approved' | 'rejected';
  language?: 'en' | 'te';
  theme?: 'light' | 'dark';
}

export type ComplaintType = 'Pothole' | 'Garbage' | 'Water Leakage' | 'Streetlight Failure' | 'Other';
export type ComplaintStatus = 'Pending' | 'Assigned' | 'In Progress' | 'Resolved' | 'Rejected';
export type Priority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface ComplaintComment {
  uid: string;
  userName: string;
  text: string;
  createdAt: string;
}

export interface Complaint {
  id: string;
  reporterUid: string;
  reporterName: string;
  type: ComplaintType;
  description: string;
  imageUrl?: string;
  location: {
    latitude: number;
    longitude: number;
    address: string;
  };
  status: ComplaintStatus;
  priority: Priority;
  assignedTo?: string;
  resolutionImageUrl?: string;
  adminRemarks?: string;
  comments?: ComplaintComment[];
  createdAt: string;
  updatedAt: string;
  aiAnalysis?: {
    detectedType: string;
    confidence: number;
    urgency: string;
    reasoning: string;
  };
}

export interface Notification {
  id: string;
  uid: string;
  title: string;
  message: string;
  complaintId: string;
  isRead: boolean;
  createdAt: string;
}

export interface Assignment {
  id: string;
  complaintId: string;
  workerUid: string;
  assignedBy: string;
  assignedAt: string;
  notes?: string;
}
