import express from "express";
import path from "path";
import fs from "fs";
import { GoogleGenAI } from "@google/genai";

// Lazy initialization helper for Gemini
let ai: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!ai) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is missing. Please define it in your Secrets / .env file.");
    }
    ai = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return ai;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set limits for larger payloads (for image upload)
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/gemini/analyze", async (req, res) => {
    try {
      const { imageUri, description } = req.body;
      if (!description) {
        return res.status(400).json({ error: "Description is required" });
      }

      const client = getGeminiClient();
      const parts: any[] = [];

      if (imageUri && imageUri.includes(",")) {
        const mimeType = imageUri.substring(imageUri.indexOf(":") + 1, imageUri.indexOf(";"));
        const base64Data = imageUri.split(",")[1];
        parts.push({
          inlineData: {
            mimeType: mimeType || "image/jpeg",
            data: base64Data,
          }
        });
      }

      parts.push({
        text: `Analyze this civic issue. Description: "${description}". 
        Identify the type of issue (Pothole, Garbage, Water Leakage, Streetlight Failure, or Other).
        Assign a priority (Low, Medium, High, Critical) based on severity and safety risk.
        Provide a brief reasoning.
        Return the result in JSON format with keys: type, priority, reasoning, urgency.`,
      });

      const result = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: parts,
        config: {
          responseMimeType: "application/json",
        }
      });

      const responseText = result.text || "{}";
      res.json(JSON.parse(responseText));
    } catch (error: any) {
      console.error("Gemini analysis error:", error);
      res.status(500).json({ error: error.message || "Failed to analyze civic issue" });
    }
  });

  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      const client = getGeminiClient();
      
      const contents = [
        ...(history || []).map((h: any) => ({
          role: h.role === 'model' ? 'model' : 'user',
          parts: h.parts ? h.parts.map((p: any) => ({ text: p.text })) : [{ text: h.text || h.message || "" }]
        })),
        { role: 'user', parts: [{ text: message }] }
      ];

      const result = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: "You are JANHITH AI, a helpful assistant for a civic issue reporting platform. Help users with reporting issues, understanding the process, and answering questions about municipal services. Keep responses concise and professional.",
        }
      });

      res.json({ response: result.text || "" });
    } catch (error: any) {
      console.error("Gemini chat error:", error);
      res.status(500).json({ error: error.message || "Failed to generate chat response" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom",
    });
    app.use(vite.middlewares);

    app.get("*", async (req, res, next) => {
      if (req.originalUrl.startsWith("/api")) {
        return next();
      }
      try {
        let template = fs.readFileSync(path.resolve(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
